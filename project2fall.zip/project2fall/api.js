// Import the Koa Module into the project
const Koa = require('koa');
// Initialize a Koa API
const api = new Koa();
// Bring the routes into the project.
const defaultRouter = require('./routes/default')

const bodyparser = require('koa-bodyparser');


// Define an API port
const API_PORT = 8217;

api.use(async (ctx,next)=>{
    await next();
    const rt =ctx.response.get('X-REsponse-time');
    console.log(`Type: ${ctx.method} PAth: ${ctx.url} Time: ${rt}`);
});

api.use(async (ctx,next)=> {
    const start =Date.now();
    await next();
    const ms =Date.now() -start;
    ctx.set('X-REsponse-Time', `${ms}ms`);
});
api.use(async (ctx,next) => {
    await next().catch(err=>{
	ctx.body =err;
	ctx.status =500;
    });
    });


api.use(bodyparser());


// Injecting the routes into the api




defaultRouter(api);
// Telling KoaJS to start listening to requests. 
api.listen(API_PORT,() => {
    console.log(`Using Port : ${API_PORT}`);
});
