const dbConnection = require('../database/connector');
class Surf_EventsController {
    static async  AllEvents (ctx) {

 try {

                    return new Promise((resolve, reject) => {
                        const query = 'Select * from Surf_Events;'

                        db.query(query, (err,res) => {
                            if(err) {
                        reject(err);
                    }
                           
			    ctx.status = 200;
                    ctx.body = res;
                            resolve();
                        });
                    });

                } catch(error) {
                    console.error(`EventController.all: ${error}`);
                }
    }


static async getbyEvent_Title(ctx) {
    try {
        return new Promise((resolve,reject) => {
            const EventTitle =ctx.params.yeet;
            const query = 'Select * from Surf_Events Where Event_Title = ?';
            db.query({
                sql: query,
                values: [EventTitle]
            }, (err,res) => {
                if(err) {
                    reject(err);
                }
                ctx.body = res;
                ctx.status =200;
                resovle ();
            });
        });
    }catch (error) {
    }}
    
static async update(ctx){
    try {
        return new promise((resolve,reject) => {
            const EventTitle =ctx.params.yeet;
            const events= ctx.request.body;

            const query = `
            Update Surf_Events
            Set Event_Date= ?,
                Event_Title = ?,
                    
                       
                       Where Event_Director = ?
            `;
            db.query({
                sql: query,
 values: [events.Event_Title, events.Event_Date,EventTitle]
            }, (err,res) => {
                if(err) {
                    reject (err);
                }
		const instE = {
		    Event_Director: EventTitle,
		    Event_Date : events.Event_Date,
		    Event_Title: events.Event_Title
		}
                ctx.body = instE;
                ctx.status =200;
                resolve();
            });
	});
        }catch(error) {
        }}

    }
module.exports = Surf_EventsController;

	
