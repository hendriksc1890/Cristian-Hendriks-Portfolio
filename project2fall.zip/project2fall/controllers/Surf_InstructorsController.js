const db = require ('../database/connector');

class Surf_InstructorsController {
    static async  AllInstructors (ctx) {
       
            
                try {

		    return new Promise((resolve, reject) => {
			const query = 'Select * from Surf_Instructors;'

			db.query(query, (err,res) => {
			    if(err) {
                        reject(err);
                    }
                    ctx.status = 200;
                    ctx.body = res;
			    resolve();
			});
		    });
			    
		} catch(error) {
                    console.error(`InstructorController.all: ${error}`);
		}
    }





 static async  Surf_TrainerProcedure (ctx) {


                try {

                    return new Promise((resolve, reject) => {
                        const query = ' Call Find_Trainer();'

                        db.query(query, (err,res) => {
                            if(err) {
                        reject(err);
                    }
                    ctx.status = 200;
                    ctx.body = res;
                            resolve();
                        });
                    });

                } catch(error) {
                    console.error(`InstructorController.all: ${error}`);
                }
    }




static async getbyName_I(ctx) {
    try {
        return new Promise((resolve,reject) => {
            const name =ctx.params.Instructor;
            const query = 'Select * from Surf_Instructors Where Name_I = ?';
            db.query({
                sql: query,
                values: [name]
            }, (err,res) => {
                if(err) {
                    reject(err);
                }
                ctx.body = res;
                ctx.status =200;
                resovle ();
            });
        });
    }catch (error) {
    }}                                                            

static async update(ctx){
    try {
        return new promise((resolve,reject) => {
            const name =ctx.params.Instructor;
            const instructor = ctx.request.body;

            const query = `
            Update Surf_Instructors,
            Set sex = ?,
                SSN = ?,
                    Years_taught =?,
                        
                       Where Name_I  = ?
            `;
            db.query({
             sql: query,
                values: [ instructor.sex,instructor.SSN, instructor.Years_taught,name]
            }, (err,res) => {
                if(err) {
                    reject (err);
                }

		const inst = {
		    name_I: name,
		    sex : instructor.sex,
		    SSN :instructor.SSN,
		    Years_taught: instructor.Years_taught
		}
                ctx.body =inst;
                ctx.status =200;
                resolve();
            });
	});
	}      catch(error) {
	}}


  static async  Surf_TrainerProcedure (ctx) {


                try {

                    return new Promise((resolve, reject) => {
                        const query = ' Call Find_Trainer();'

                        db.query(query, (err,res) => {
                            if(err) {
                        reject(err);
                    }
                    ctx.status = 200;
                    ctx.body = res;
                            resolve();
                        });
                    });

                } catch(error) {
                    console.error(`InstructorController.all: ${error}`);
                }
    }

}
			   
 module.exports = Surf_InstructorsController;
