
const dbConnection = require('../database/connector');

class DemoController {
    static async  NewMethod  (ctx) {
        return new Promise((resolve, reject) => {
            dbConnection.query('Select * from BK_Student', (err, res) => {
                try {
                    if(err) {
                        reject(err);
                    }
                    ctx.status = 200;
                    ctx.body = res;
                    resolve();
                } catch(err_1) {
                    console.log(err_1);
                }
            });
        });
    }
}


static async getById(ctx) {
    try {
	return new promise((resolve,reject)=> {
	    const query = ' ';
	    db.query(query, (err,res) => {
		if(err)
module.exports = DemoController;
