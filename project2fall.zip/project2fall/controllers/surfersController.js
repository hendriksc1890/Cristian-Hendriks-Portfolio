const db = require ('../database/connector');




class surfersController {
    static async  AllSurfers (ctx) {

 try {

                    return new Promise((resolve, reject) => {
                        const query = 'Select * from surfers;'

                        db.query(query, (err,res) => {
                            if(err) {
                        reject(err);
                    }
	               ctx.body =res;
                    ctx.body = res;
                            resolve();
                        });
                    });

                } catch(error) {
                    console.error(`surfersController.AllSurfers: ${error}`);
                }
    }


      static async  view_surfmerch (ctx) {

 try {

                    return new Promise((resolve, reject) => {
                        const query = 'select * from (Merch_info);'

                        db.query(query, (err,res) => {
                            if(err) {
                        reject(err);
                    }
                    ctx.status = 200;
                    ctx.body = res;
                            resolve();
                        });
                    });

                } catch(error) {
                    console.error(`surfersController.all: ${error}`);
                }
    }







    

static async getbyid(ctx) {
    try {
	return new Promise((resolve,reject) => {
	    const surfersID =ctx.params.ID;
	    const query = 'Select * from surfers Where ID = ?';
	    db.query({
		sql: query,
		values: [surfersID]
	    }, (err,res) => {
		if(err) {
		    reject(err);
		}
		ctx.body = res;
		ctx.status =200;
		resovle ();
	    });
	});
    }catch (error) {
    }}

static async update(ctx){
    try {
	return new promise((resolve,reject) => {
	    const surfersID =ctx.params.id;
	    const  surfers = ctx.request.body;
	    
	    const query = `
            Update surfers 
            Set Surf_Level = ?,
                    Name_S =?,
                       Surfer_type =?
                       Where ID = ?
            `;
	    db.query({
		sql: query,
		values: [ surfers.Surf_Level, surfers.Name_S, surfers.Surfer_type, surfersID]
	    }, (err,res) => {
		if(err) {
		    reject (err);
		}
		const instS = {
			       Surf_Level: surfers.Surf_Level,
			       Name_S: surfesr.Name_S,
			       Surfer_type: surfers. Surfer_type
			      }
		ctx.body =instS;
		ctx.status =200;
		resolve();
	    });
	});
	}catch(error) {
	}}
}


module.exports= surfersController;
