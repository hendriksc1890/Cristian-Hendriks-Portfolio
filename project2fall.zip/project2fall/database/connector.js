const mysql = require('mysql');

const config = {
    debug: false,
    host: '127.0.0.1',
    port: '8217',
    user: 'hendriks_cs355fl20',
    password: 'he5244933',
    database: 'hendriks_cs355fl20'
};
const dbConnection = mysql.createConnection(config);
module.exports = dbConnection;
