const events = require('../controllers/Surf_EventsController');
const Surf_EventRouter = require('koa-router')({
    prefix: '/events'
});
Surf_EventRouter.get('/', events.AllEvents);
Surf_EventRouter.get('/:yeet', events.getbySurf_Events);
Surf_EventRouter.put('/:yeet', events.update);
module.exports = Surf_EventRouter;

