 const instructor = require('../controllers/Surf_InstructorsController');
const Surf_InstructorsRouters = require('koa-router')({
    prefix: '/instructor'
});

Surf_InstructorsRouters.get('/', instructor.AllInstructors);


Surf_InstructorsRouters.get('/',instructor.Surf_TrainerProcedure);

Surf_InstructorsRouters.get('/:Instructor',instructor.getbyName_I);
Surf_InstructorsRouters.put('/:Instructor',instructor.update);

module.exports = Surf_InstructorsRouters;
