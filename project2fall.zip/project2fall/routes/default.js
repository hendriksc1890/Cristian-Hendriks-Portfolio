// Import other routers that will branch off of the default route.
/*
const Surf_InstructorsController.js = require('../controllers/Surf_EventsController');
const Surf_EventsController.js = require('../controllers/Surf_EventsController');
const surfersController.js = require('../controllers/surfersController');
const demoController =require('../constrollers/demoController');
*/

const surfersRouter =require('./surfers');

const Surf_InstructorsRouters =require('./Surf_Instructors');


/*    const Surf_EventRouter =require('./Surf_Events'); 

const demoRouter = require ('./demoRouter');*/

const route = require('koa-router')

({
    prefix: '/api/v1'
   
    });

route.get('/', (ctx)=> {
   
    ctx.body ='Default route hit';
});


route.get('/hello',(ctx) => {
    ctx.status=200;
    ctx.body = 'Hey buddy'
});

route.use(
 //   demoRouter.routes(),
    surfersRouter.routes(),
   // Surf_EventRouter.routes(),
    Surf_InstructorsRouters.routes()
);


function addRoutesToAPI (api) {
    api.use(route.routes());
    api.use(route.allowedMethods());
}





module.exports =(api)=> {
    api.use(route.routes());
};
// A basic KoaJS router
// Parameter 1: Route Path
// Parameter 2: Function to execute when this route activates
// API Path: /api/v1/s

/*
defaultRouter.get('/',( ctx) => {
    ctx.status = 200;
    ctx.body = {route: "Default"};
});
 
defaultRouter.get('/hw',(ctx)=> {
    ctx.status= 200;
    ctx.body = 'Hello World'
});

defaultRouter.get('/hello/:you', (ctx) => {
    let you =ctx.params.you;
    ctx.body= ` Hello ${you}`;
});

defaultRouter.post('/hello/', (ctx) => {
    let you =ctx.request.body.MyParam;
    ctx.status =200
    ctx.body = `Hello ${you} `;
});
// Function to inject routes to Koa API
function addRoutesToAPI (api) {
    api.use(defaultRouter.routes());
    api.use(defaultRouter.allowedMethods());
}
defaultRoute.use(
    demoRouter.routes(),
    surfersRouter.routes(),
    Surf_EventRouter.routes(),
    Surf_InstructorsRouters.routes()
);
module.exports = addRoutesToAPI;
*/
