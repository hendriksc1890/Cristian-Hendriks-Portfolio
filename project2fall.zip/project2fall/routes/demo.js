const demoController = require('../controllers/demoController');


const demoRouter =require('koa-router')({
    prefix: '/demoRouter'
});



demoRouter.get('/', demoController.demoMethod);





module.exports= demoRouter;
