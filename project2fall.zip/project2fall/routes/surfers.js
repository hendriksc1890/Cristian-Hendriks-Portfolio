
const surfers = require('../controllers/surfersController');
const surfersRouter = require('koa-router')({
    prefix: '/surfers'
});

surfersRouter.get('/', surfers.AllSurfers);
surfersRouter.get('/:id', surfers.getbyid);



  surfersRouter.get('/', surfers.view_surfmerch);

surfersRouter.put('/:id', surfers.update);

module.exports =surfersRouter;
